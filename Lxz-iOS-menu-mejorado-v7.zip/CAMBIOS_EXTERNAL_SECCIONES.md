# Cambios del menú External

- Se mantienen las pestañas AIMBOT y TEXTURAS del menú neón.
- AIMBOT muestra PECHO AVATAR, HEAD AVATAR, CUELLO AVATAR y SINTURA AVATAR.
- TEXTURAS muestra el encabezado HOLOGRAMA ARMA y el botón HOLOGRAMA AZUL AVATAR.
- El botón HOLOGRAMA AZUL AVATAR ahora importa el archivo `Holograma Vip Jere Store.3105` incluido en los recursos de la app a la biblioteca Patches, usando el importador .3105 existente.
- La importación no aplica automáticamente el paquete al juego. El contenido del archivo está cifrado y no se ha podido verificar externamente; revisa el paquete antes de cualquier aplicación.
- Los controles AIMBOT permanecen como elementos de interfaz y no se añade lógica de apuntado automático.
